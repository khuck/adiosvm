#include "pipe/p_compiler.h"

PUBLIC const int st_api_OpenGL_ES2 = 1;
